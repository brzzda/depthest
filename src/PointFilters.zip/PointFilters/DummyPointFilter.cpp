//
// Created by peetaa on 22.4.2018.
//

#include <HelperFunctions.h>
#include "DummyPointFilter.h"

DummyPointFilter::DummyPointFilter() {
    pose = cv::Mat(3,1, CV_32FC1);
    pose = 0;
    first = true;
}

DummyPointFilter::~DummyPointFilter() {

}

void DummyPointFilter::update(cv::Mat point) {
    distance = getDistance(pose, point);
    point.copyTo(pose);
}

cv::Mat DummyPointFilter::getEstimate() {
    return pose;
}

float DummyPointFilter::getPoseChange() {
    if (first) {
        first = false;
        return 0;
    }
    return distance;
}
