//
// Created by peetaa on 22.4.2018.
//

#ifndef DEPTHEST_POINTFILTERFACTORY_H
#define DEPTHEST_POINTFILTERFACTORY_H

#include "PointFilter.h"
#include "KalmanPointFilter.h"
#include "MedianWindowPointFilter.h"
#include "MedianPointFilter.h"
#include "DummyPointFilter.h"

class PointFilterFactory {
private:
    MedianWindowPointFilter mwpf;
    MedianPointFilter mpf;
    KalmanPointFilter kpf;
    DummyPointFilter dpf;
public:
    PointFilterFactory(){};
    PointFilter* getPointFilter(int pointFilter);
};


#endif //DEPTHEST_POINTFILTERFACTORY_H
