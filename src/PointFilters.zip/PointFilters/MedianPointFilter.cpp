//
// Created by Peter Zborovský on 21.4.2018.
//

#include <iostream>
#include "MedianPointFilter.h"
#include "HelperFunctions.h"


MedianPointFilter::MedianPointFilter() {
    countAvg = 0;
    countMed = 0;
    pose = cv::Mat(3,1, CV_32FC1);
    pose = 0;
    first = true;
}

MedianPointFilter::~MedianPointFilter() {
    Z.clear();
    Y.clear();
    X.clear();
}

void MedianPointFilter::update(cv::Mat point) {
//    std::cout << "pt3D update" << std::endl;
//    outputMatInfo(point, "pt3d inserted point");
    X.push_back(point.at<float>(0,0));
//    std::cout << "111" << std::endl;
    Y.push_back(point.at<float>(1,0));
//    std::cout << "222" << std::endl;
    Z.push_back(point.at<float>(2,0));
//    std::cout << "333" << std::endl;
    estimatedPose = estimatePose();
    distance = getDistance(pose, estimatedPose);
    estimatedPose.copyTo(pose);
//    pose.copyTo(estimatedPose);
//    point.copyTo(pose);
    countAvg++;
    countMed++;
//    std::cout << "pt3D update FINITO" << std::endl;
}

cv::Mat MedianPointFilter::getEstimate() {
    return estimatedPose;
}

float MedianPointFilter::getPoseChange() {
    if (first) {
        first = false;
        return 0;
    }
    return distance;
}

cv::Mat MedianPointFilter::estimatePose() {
    cv::Mat res;
    std::vector<float> x;
    std::vector<float> z;
    std::vector<float> y;
    ulong id = countMed / 2;

    cv::sort(X, x, CV_SORT_ASCENDING);
    cv::sort(Y, y, CV_SORT_ASCENDING);
    cv::sort(Z, z, CV_SORT_ASCENDING);

    res.push_back(x[id]);
    res.push_back(y[id]);
    res.push_back(z[id]);
    return res;
}
