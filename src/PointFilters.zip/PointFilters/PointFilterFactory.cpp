//
// Created by peetaa on 22.4.2018.
//

#include <HelperFunctions.h>
#include "PointFilterFactory.h"

PointFilter* PointFilterFactory::getPointFilter(int pointFilter) {
    if (pointFilter == KALMAN_POINT_FILTER) {
        KalmanPointFilter kf;
        return &kf;
        return &kpf;
    } else if (pointFilter == MEDIAN_POINT_FILTER){
        MedianPointFilter mf;
        return &mf;
//        return &mpf;
    } else if (pointFilter == MEDIAN_WINDOW_PONT_FILTER) {
        MedianWindowPointFilter mfw;
        return &mfw;
//        return &mwpf;
    }
    DummyPointFilter df;
    return &df;
//    return &dpf;
}
